import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Game {
    Scanner scanner = new Scanner(System.in);
    List<Player> players = new ArrayList<>();
    Dealer dealer;
    int clientNum;

    public Game() {
        //System.out.println("참가자 수 >>");
        //clientNum = scanner.nextInt();
        //System.out.println("이름 입력하세요");
        //String name  = scanner.nextLine();
        String name = "shin";
        players.add(new Player(name));
        //Deck deck = new Deck();
        //deck.shuffle();
        //deck.print();
        Bet bet = new Bet(players);
        new Dealer(players);
    }

    public static void main(String[] args) {
        new Game();
    }
}

