public class Hand { // 플레이어의 핸드에 있는 패
    Card[] ownCards = new Card[2];
    public Hand(Dealer dealer) {
        for (int i = 0; i < 2; i++) {
            ownCards[i] = dealer.personalCard();
        }
    }
}
