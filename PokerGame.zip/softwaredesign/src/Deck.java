import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class Deck {
    private ArrayList<Card> cards;

    public Deck() {
        this.cards = new ArrayList<Card>();
        String[] suits = {"♣", "♥️", "♦️", "♠"};
        String[] ranks = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};

        for (String suit : suits) {
            for (String rank : ranks) {
                this.cards.add(new Card(suit, rank));
            }
        }
    }

    public void shuffle() {
        Collections.shuffle(this.cards);
    }

    public Card drawCard() {
        Card card = this.cards.get(0);
        this.cards.remove(0);
        return card;
    }

    public void print() {
        for (int i = 0; i < 52; i++) {
            Card card = cards.get(i);
            System.out.println(card.showCard());
        }
    }
}
