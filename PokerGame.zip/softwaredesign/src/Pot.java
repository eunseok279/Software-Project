import java.util.ArrayList;
import java.util.List;

public class Pot {
    private int potMoney;
    List<Player> players;
    Dealer dealer;

    public Pot(List<Player> players, Dealer dealer) {
        potMoney = 0;
        this.players = players;
        this.dealer = dealer;
    }

    public void blind(int avgMoney, int who) { // 시작 강제 베팅
        int money = (int) (avgMoney * 0.01); // 블라인드는 평균 금액의 1%
        Player player = players.get(who);
        player.betMoney(money);
        plusPot(money);
        player.hand = new Hand(dealer);
    }

    public void flop(int money) { // 1라운드 베팅

    }

    public void turn(int money) { // 2라운드 베팅

    }

    public void river(int money) { // 3라운드 베팅

    }

    public void plusPot(int money) {
        potMoney += money;
    }

    public int getPot() {
        return potMoney;
    }
}
