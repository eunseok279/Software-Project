import java.util.List;

public class Dealer {
    Pot pot;
    Card[] tableCard = new Card[5];
    Deck deck =new Deck();
    public Dealer(List<Player> players){
        pot = new Pot(players,this);
        deck.shuffle();
        Player player = players.get(0);
        System.out.println(player.getName());
        System.out.println(player.getState());
        System.out.println(player.getMoney());
        pot.blind(player.getMoney(),0);
        System.out.println(pot.getPot());
        System.out.println(player.hand.ownCards[0].showCard());
        System.out.println(player.hand.ownCards[1].showCard());
    }
    public Card personalCard(){
        return deck.drawCard();
    }
}
