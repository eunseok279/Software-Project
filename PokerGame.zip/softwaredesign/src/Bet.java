import java.util.List;

public class Bet {
    List<Player> players;

    public Bet(List<Player> players) {
        this.players = players;
    }

    public void call(int pMoney) {

    }

    public void raise(int money) {

    }

    public void fold(Player player) {
        player.setStateFold();
    }

    public void check() {

    }

    public void allIn(int order) {
        players.get(order).betMoney(players.get(order).getMoney());
    }
}
