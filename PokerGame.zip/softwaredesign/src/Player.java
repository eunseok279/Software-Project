public class Player {
    private String name;
    private int money;
    private int state;
    final int BANKRUPTCY = -1, FOLD = 0, LIVE = 1;
    Hand hand;

    public Player(String name) {
        this.name = name;
        this.state = LIVE;
        this.money = 100000; // 초기 돈(단위 : 원)
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setStateFold() {
        this.state = FOLD;
    } // 폴드 시 false로 변경

    public void setStateBankruptcy() {
        this.state = BANKRUPTCY;
    }

    public int getState() {
        return this.state;
    }

    public void betMoney(int money) {
        this.money -= money;
    }

    public int getMoney() {
        return money;
    }
}
