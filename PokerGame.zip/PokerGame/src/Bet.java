public class Bet {
}
