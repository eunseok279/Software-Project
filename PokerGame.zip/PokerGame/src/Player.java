public class Player {
    private String name;
    private boolean state;

    public Player(String name){
        this.name = name;
        this.state = true;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
