public class Pot {
    int money[] = new int[5];
}
