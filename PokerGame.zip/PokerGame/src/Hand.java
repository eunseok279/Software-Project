public class Hand {

}
