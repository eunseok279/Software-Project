import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Game {
    Scanner scanner = new Scanner(System.in);
    List<Player> players = new ArrayList<>();
    Dealer dealer;
    int clientNum;

    public Game() {
        //System.out.println("참가자 수 >>");
        //clientNum = scanner.nextInt();
        //System.out.println("이름 입력하세요");
        //String name  = scanner.nextLine();
        String name = "shin";
        players.add(new Player(name));
        //Deck deck = new Deck();
        //deck.shuffle();
        //deck.print();
        System.out.println("============================");
        System.out.println("텍사스 홀덤 게임이 시작되었습니다.");
        System.out.println("============================");
        System.out.println("유저 1번 정보 >> " + players.get(0).getName() + ", 소지 금액 >>" + players.get(0).getMoney());
        new Dealer(players);
    }

    public static void main(String[] args) {
        new Game();
    }
}

