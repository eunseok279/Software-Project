import java.util.List;

public class Bet { // ���� ���
    Player player;
    int money;
    int basicBet = 2000;

    public Bet(Player player) {
        this.player = player;
    }

    public int call() {
        while (true) {
            System.out.print("Betting >> ");
            money = player.getAnswer();
            if (money > player.getMoney()) {
                System.out.println("Not Enough Money");
                continue;
            }
            if (money < basicBet) {
                System.out.println("Basic Betting Money is 2000");
                continue;
            }
            player.betMoney(money);
            break;
        }
        return money;
    }

    public int raise() {
        while (true) {
            money = player.getAnswer();
            if (money > player.getMoney()) {
                System.out.println("Not Enough Money");
                continue;
            }
            player.betMoney(money);
            break;
        }
        return money;
    }

    public void fold(Player player) {
        player.setStateFold();
    }

    public void check() {

    }

    public int allIn() {
        money = player.getMoney();
        player.betMoney(money);
        return money;
    }
}
