import java.util.*;

public class Dealer { // 판을 깔아줄 컴퓨터 및 시스템
    Pot pot;
    List<Card> tableCard = new ArrayList<>(); // table에 있는 패
    Deck deck = new Deck();
    List<Player> players;

    List<Player> winners;

    public Dealer(List<Player> player) {
        this.players = player;
        while (true) {
            pot = new Pot(players);
            deck.shuffle();
            setDealerButton(players);
            System.out.println("Dealer button is >> " + players.get(0).getName());
            Player p = players.get(0);
            p.hand = new Hand(this);
            //pot.smallBlind(0);
            p.hand.showHand();
            p.hand.showPedigree();
            System.out.println("1.Call 2. Raise 3. Fold 4. Check");
            pot.flop(players.indexOf(p));
            System.out.println("Current Pot >> " + pot.getPot());
            if (p.getState() == p.FOLD) continue;
            for (int i = 0; i < 3; i++) addCard(deck.drawCard()); // 서버에서 드로우 결국 한번만 실행
            p.hand.showHand();
            p.hand.showPedigree();
            System.out.println("1.Call 2. Raise 3. Fold 4. Check");
            pot.turn(0);
            System.out.println("Current Pot >> " + pot.getPot());
            if (p.getState() == p.FOLD) continue;
            addCard(deck.drawCard());
            p.hand.showHand();
            p.hand.showPedigree();
            System.out.println("1.Call 2. Raise 3. Fold 4. Check");
            pot.river(0);
            System.out.println("Current Pot >> " + pot.getPot());
            if (p.getState() == p.FOLD) continue;
            addCard(deck.drawCard());
            p.hand.showHand();
            p.hand.showPedigree();
            winners = determineWinners(players);
            for (Player pl : winners)
                System.out.println("Winner is " + pl.getName());
            System.out.println("Current Pot >> " + pot.getPot());
            winners.get(0).plusMoney(pot.getPot());
            System.out.println("유저 1번 정보 >> " + p.getName() + ", 소지 금액 >>" + p.getMoney());
            deck.initCard();
        }
    }

    public void getPersonalCard(List<Card> own) {
        for (int i = 0; i < 2; i++) {
            own.add(deck.drawCard());
        }
    }

    public void addCard(Card card) {
        tableCard.add(card);

        for (Player player : players)
            player.hand.ownCards.add(card);
    }

    public int compareHands(Player p1, Player p2) {
        Hand.HandRank p1HandRank = p1.hand.determineHandRank();
        Hand.HandRank p2HandRank = p2.hand.determineHandRank();

        if (p1HandRank.ordinal() < p2HandRank.ordinal()) {
            return 1; // 이 포커 손이 더 강함
        } else if (p1HandRank.ordinal() > p2HandRank.ordinal()) {
            return -1; // 다른 포커 손이 더 강함
        } else {
            switch (p1HandRank) {
                case ROYAL_FLUSH:
                    // 로열 플러시는 항상 동점입니다.
                    return 0;
                case FLUSH:
                case STRAIGHT_FLUSH:
                case STRAIGHT:
                    // 가장 높은 숫자의 카드를 비교합니다.
                    return compareHighestCard(p1.hand, p2.hand);
                case FOUR_OF_A_KIND:
                    // 같은 숫자 카드 네 장의 숫자를 비교합니다.
                    return compareQuads(p1.hand, p2.hand);
                case FULL_HOUSE:
                    // 세 장의 같은 숫자 카드를 비교하고 동점이면, 한 쌍의 같은 숫자 카드를 비교합니다.
                    return compareTripsAndPair(p1.hand, p2.hand);
                case HIGH_CARD:
                    // 가장 높은 숫자의 카드부터 차례대로 비교합니다.
                    return compareHighestCardInturn(p1.hand, p2.hand);
                case THREE_OF_A_KIND:
                    return compareThreePairsAndKicker(p1.hand, p2.hand);
                case TWO_PAIR:
                    // 높은 숫자의 쌍을 비교하고, 동점이면 낮은 숫자의 쌍을 비교한 다음, 동점이면 킥커(남은 카드)를 비교합니다.
                    return compareTwoPairsAndKicker(p1.hand, p2.hand);
                case ONE_PAIR:
                    // 같은 숫자 카드 쌍을 비교하고, 동점이면 킥커를 차례대로 비교합니다.
                    return comparePairAndKickers(p1.hand, p2.hand);
                default:
                    throw new IllegalStateException("Unexpected hand rank: " + p1HandRank);
            }
        }
    }

    private int compareThreePairsAndKicker(Hand h1, Hand h2) {
        List<Integer> h1Three = h1.getThreePairRanks();
        List<Integer> h2Three = h2.getThreePairRanks();

        int higherPairComparison = h1Three.get(0).compareTo(h2Three.get(0));
        if (higherPairComparison != 0) {
            return higherPairComparison;
        }
        int h1Kicker = h1.getKickerRank(h1Three);
        int h2Kicker = h2.getKickerRank(h2Three);
        return Integer.compare(h1Kicker, h2Kicker);
    }

    private int compareHighestCardInturn(Hand h1, Hand h2) {
        Card h1HighestCard = h1.findHighestCardInAll(); // h1의 가장 높은 카드를 찾는 메서드
        Card h2HighestCard = h2.findHighestCardInAll(); // h2의 가장 높은 카드를 찾는 메서드

        if (h1HighestCard.rank().ordinal() > h2HighestCard.rank().ordinal()) {
            return 1;
        } else if (h1HighestCard.rank().ordinal() < h2HighestCard.rank().ordinal()) {
            return -1;
        } else {
            return 0;
        }
    }

    private int compareHighestCard(Hand h1, Hand h2) {
        Card h1HighestCard = h1.getHighestCardInCombination(); // 스트레이트에 따라 h1의 가장 높은 카드를 얻는 메서드
        Card h2HighestCard = h2.getHighestCardInCombination(); // 스트레이트에 따라 h2의 가장 높은 카드를 얻는 메서드

        return Integer.compare(h1HighestCard.rank().ordinal(), h2HighestCard.rank().ordinal());
    }

    private int compareQuads(Hand h1, Hand h2) {
        List<Integer> h1Quad = h1.getQuadsRank();
        List<Integer> h2Quad = h2.getQuadsRank();

        int higherPairComparison = h1Quad.get(0).compareTo(h2Quad.get(0));
        if (higherPairComparison != 0) {
            return higherPairComparison;
        }
        int h1Kicker = h1.getKickerRank(h1Quad);
        int h2Kicker = h2.getKickerRank(h2Quad);
        return Integer.compare(h1Kicker, h2Kicker);
    }

    private int compareTripsAndPair(Hand h1, Hand h2) {
        List<Integer> h1Three = h1.getThreePairRanks();
        List<Integer> h2Three = h2.getThreePairRanks();

        int higherTPairComparison = h1Three.get(0).compareTo(h2Three.get(0));
        if (higherTPairComparison != 0) {
            return higherTPairComparison;
        }

        List<Integer> h1PairRanks = h1.getPairRanks();
        List<Integer> h2PairRanks = h2.getPairRanks();

        int higherPairComparison = h1PairRanks.get(0).compareTo(h2PairRanks.get(0));
        return higherPairComparison;
    }

    private int compareTwoPairsAndKicker(Hand h1, Hand h2) {
        List<Integer> h1PairRanks = h1.getTwoPairRanks();
        List<Integer> h2PairRanks = h2.getTwoPairRanks();

        // 높은 숫자의 쌍을 비교합니다.
        int higherPairComparison = h1PairRanks.get(0).compareTo(h2PairRanks.get(0));
        if (higherPairComparison != 0) {
            return higherPairComparison;
        }

        // 낮은 숫자의 쌍을 비교합니다.
        int lowerPairComparison = h1PairRanks.get(1).compareTo(h2PairRanks.get(1));
        if (lowerPairComparison != 0) {
            return lowerPairComparison;
        }

        // 킥커(남은 카드)를 비교합니다.
        int h1Kicker = h1.getKickerRank(h1PairRanks);
        int h2Kicker = h2.getKickerRank(h2PairRanks);
        return Integer.compare(h1Kicker, h2Kicker);
    }

    private int comparePairAndKickers(Hand h1, Hand h2) {
        List<Integer> h1PairRanks = h1.getPairRanks();
        List<Integer> h2PairRanks = h2.getPairRanks();

        int higherPairComparison = h1PairRanks.get(0).compareTo(h2PairRanks.get(0));
        if (higherPairComparison != 0) {
            return higherPairComparison;
        }
        int h1Kicker = h1.getKickerRank(h1PairRanks);
        int h2Kicker = h2.getKickerRank(h2PairRanks);
        return Integer.compare(h1Kicker, h2Kicker);
    }


    public List<Player> determineWinners(List<Player> players) {
        List<Player> currentWinners = new ArrayList<>();
        currentWinners.add(players.get(0)); //1번 플레이어

        for (int i = 1; i < players.size(); i++) { // 234 플레이어
            Player currentPlayer = players.get(i);
            int comparisonResult = compareHands(currentWinners.get(0), currentPlayer);

            if (comparisonResult < 0) { // 현재 플레이어를 다른 플레이어가 이긴 경우
                currentWinners.clear();
                currentWinners.add(currentPlayer);
            } else if (comparisonResult == 0) { // 동점인 경우
                currentWinners.add(currentPlayer);
            }
        }
        return currentWinners;
    }

    private void setDealerButton(List<Player> players) {
        Map<Integer, Card> cardMap = new HashMap<>();
        for (int i = 0; i < players.size(); i++)
            cardMap.put(i, deck.drawCard());
        List<Map.Entry<Integer, Card>> entry = new ArrayList<>(cardMap.entrySet());
        Collections.sort(entry, new Comparator<Map.Entry<Integer, Card>>() {
            @Override
            public int compare(Map.Entry<Integer, Card> o1, Map.Entry<Integer, Card> o2) {
                int rankComp = o2.getValue().rank().compareTo(o1.getValue().rank());
                if (rankComp == 0) return o2.getValue().suit().compareTo(o1.getValue().suit());
                return rankComp;
            }
        });
        rearrangeOrder(players, entry.get(0).getKey());
        deck.initCard();
        deck.shuffle();
    }

    private static List<Player> rearrangeOrder(List<Player> playerOrder, int dealerButtonIndex) {
        List<Player> newOrder = new ArrayList<>();
        for (int i = dealerButtonIndex; i < playerOrder.size(); i++) {
            newOrder.add(playerOrder.get(i));
        }
        for (int i = 0; i < dealerButtonIndex; i++) {
            newOrder.add(playerOrder.get(i));
        }
        return newOrder;
    }
}

