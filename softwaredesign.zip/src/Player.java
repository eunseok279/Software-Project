import java.util.Scanner;

public class Player { // 플레이어의 정보가 담긴 클래스
    private String name;
    private int money;
    private int state;
    final int BANKRUPTCY = 0, LIVE = 1, WINNER = 2;
    final int CALL = 1, RAISE = 2, FOLD = 3, CHECK = 4, ALLIN = 5;
    Hand hand;
    Bet bet;

    public Player(String name) {
        this.name = name;
        this.state = LIVE;
        this.money = 100000; // 초기 돈(단위 : 원)
        bet = new Bet(this);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setStateFold() {
        this.state = FOLD;
    } // 폴드 시 상태 0으로(폴드 상태)로 변경

    public void setStateBankruptcy() {
        this.state = BANKRUPTCY;
    } // 파산 시 -1 상태로 변경 후 퇴장

    public int getState() {
        return this.state;
    }

    public void betMoney(int money) {
        this.money -= money;
    }

    public int getMoney() {
        return money;
    }

    public void plusMoney(int money) {
        this.money += money;
    }

    public int getAnswer() {
        Scanner scanner = new Scanner(System.in);
        return scanner.nextInt();
    }

    public int betting() {
        int money = 0;
        switch (getAnswer()) {
            case CALL:
                money = bet.call();
                break;
            case RAISE:
                money = bet.raise();
                break;
            case FOLD:
                bet.fold(this);
                break;
            case CHECK:
                bet.check();
                break;
            case ALLIN:
                money = bet.allIn();
                break;
        }
        return money;
    }
}
