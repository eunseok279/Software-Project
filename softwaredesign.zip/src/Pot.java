import java.util.ArrayList;
import java.util.List;

public class Pot {
    private int potMoney;
    List<Player> players;

    public Pot(List<Player> players) {
        potMoney = 0;
        this.players = players;
    }

    public void smallBlind(int who) { // 시작 강제 베팅
        Player player = players.get(who);
        player.betMoney(1000);
        plusPot(1000);
    }

    public void bigBlind(int who) {
        Player player = players.get(who);
        player.betMoney(2000);
        plusPot(2000);
    }

    public void flop(int who) { // 1라운드 베팅
        Player player = players.get(who);
        int money = player.betting();
        plusPot(money);
    }

    public void turn(int who) { // 2라운드 베팅
        Player player = players.get(who);
        int money = player.betting();
        plusPot(money);
    }

    public void river(int who) { // 3라운드 베팅
        Player player = players.get(who);
        int money = player.betting();
        plusPot(money);
    }

    public void plusPot(int money) {
        potMoney += money;
    }

    public int getPot() {
        return potMoney;
    }
}
